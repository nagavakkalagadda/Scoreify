# Building Your Local Cricket Scoreboard App: Complete Match & Super Over Edition

Welcome to your complete cricket scoring guide! This guide explains how the app tracks **every ball of every over**, calculates the **sum of each over**, executes **No-Ball + Boundary (4) → Free Hit**, maintains a **Full Innings Batting & Bowling Scorecard**, and enforces all official **Super Over Rules**.

---

## 1. Official Super Over Rules & Mechanics (`🔥 Super Over Mode`)

When a match ends in a tie—or whenever local organizers click **🔥 Start Super Over (Tie-Breaker Mode)**—the app switches into official Super Over rules:

| Rule | Regulation Match | Super Over Mode |
| :--- | :--- | :--- |
| **Max Overs per Innings** | Configured by organizer (e.g., 10, 15, 20) | **Strictly 1 Over (6 legal deliveries)** |
| **Max Wickets ("All Out")** | **10 Wickets** | **2 Wickets Max** (3 nominated batsmen; losing 2 wickets ends the innings immediately) |
| **Batting Order** | `Team 1` bats 1st, `Team 2` chases | **Reverse Order**: The team that batted **2nd** in the main match bats **1st** in the Super Over (with an option to swap if local rules differ) |
| **Tied Super Over** | Triggers Super Over #1 | **Repeat Super Over (#2, #3...)**: If a Super Over also ties, clicking `Start Super Over` launches the next Super Over with reversed batting order |
| **Regulation History** | Live on scoreboard | Saved into `regulationHistoryNotes` and included in the **WhatsApp Share** export |

---

## 2. How the "No-Ball + Boundary (4) → Free Hit" Sequence Works

When you record a No-Ball via the **No Ball (NB)** drawer followed by the next delivery, here is the exact sequence the app executes:

| Step | Action | Team Score | Legal Balls / Overs | Striker Stats | Over Ribbon & Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1. No-Ball + 4** | Tap `No Ball (NB)` → `NB + 4 Boundary (5)` | **+5 Runs** (1 NB penalty + 4 bat runs) | `0.0` (Does **not** count as a legal ball) | **+4 Runs**, `+1 Ball`, `4s: +1` | Logs `NB+4` badge; activates **⚡ FREE HIT ACTIVE ON THIS BALL ⚡** |
| **2. Free Hit Ball** | Tap `6` (or any run on the Free Hit) | **+6 Runs** (Total: **11 Runs**) | `0.1` (Consumes the legal delivery & Free Hit) | **+6 Runs**, `+1 Ball`, `6s: +1` | Logs `FH(6)` badge with gold ring; turns off Free Hit banner |

---

## 3. Complete Over-by-Over Record & Full Innings Scorecard

- **Live Current Over Sum**: `getCurrentOverSum()` sums `runsAdded` across every delivery in the current over.
- **Complete Over-by-Over History Log**: Archives every completed over (or a Super Over ending early on the 2nd wicket) with the Over Number, Bowler Name, ball badges, Over Sum, and Team Score.
- **Full Batting & Bowling Tables**: Tracks all dismissed batsmen (`dismissedBatsmen`) alongside the two unbeaten batsmen, and preserves multi-spell bowler figures (`bowlersMap`).